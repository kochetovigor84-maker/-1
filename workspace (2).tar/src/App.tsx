import { useState } from 'react';
import { Car, CarFormData } from './types/car';
import { useCars } from './hooks/useCars';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { CarList } from './components/CarList';
import { CarForm } from './components/CarForm';
import { CarDetail } from './components/CarDetail';

type View = 'dashboard' | 'fleet';

function App() {
  const { cars, addCar, updateCar, deleteCar } = useCars();
  const [activeTab, setActiveTab] = useState<View>('dashboard');
  const [showForm, setShowForm] = useState(false);
  const [editingCar, setEditingCar] = useState<Car | null>(null);
  const [viewingCar, setViewingCar] = useState<Car | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);

  const handleAdd = () => {
    setEditingCar(null);
    setShowForm(true);
  };

  const handleEdit = (car: Car) => {
    setViewingCar(null);
    setEditingCar(car);
    setShowForm(true);
  };

  const handleFormSubmit = (data: CarFormData) => {
    if (editingCar) {
      updateCar(editingCar.id, data);
    } else {
      addCar(data);
    }
    setShowForm(false);
    setEditingCar(null);
  };

  const handleDelete = (id: string) => {
    setShowDeleteConfirm(id);
  };

  const confirmDelete = () => {
    if (showDeleteConfirm) {
      deleteCar(showDeleteConfirm);
      setShowDeleteConfirm(null);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header activeTab={activeTab} onTabChange={setActiveTab} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
        {activeTab === 'dashboard' ? (
          <div>
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Панель управления</h2>
              <p className="text-gray-500 mt-1">Обзор состояния автопарка</p>
            </div>
            <Dashboard cars={cars} />
          </div>
        ) : (
          <div>
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Автопарк</h2>
              <p className="text-gray-500 mt-1">Управление автомобилями компании</p>
            </div>
            <CarList
              cars={cars}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onView={setViewingCar}
              onAdd={handleAdd}
            />
          </div>
        )}
      </main>

      {/* Form Modal */}
      {showForm && (
        <CarForm
          car={editingCar}
          onSubmit={handleFormSubmit}
          onClose={() => {
            setShowForm(false);
            setEditingCar(null);
          }}
        />
      )}

      {/* Detail Modal */}
      {viewingCar && (
        <CarDetail
          car={viewingCar}
          onClose={() => setViewingCar(null)}
          onEdit={handleEdit}
        />
      )}

      {/* Delete Confirmation */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl p-6 max-w-sm w-full">
            <h3 className="text-lg font-bold text-gray-900 mb-2">Удалить автомобиль?</h3>
            <p className="text-sm text-gray-500 mb-6">
              Это действие нельзя отменить. Все данные об автомобиле будут удалены.
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowDeleteConfirm(null)}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
              >
                Отмена
              </button>
              <button
                onClick={confirmDelete}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-700 rounded-lg transition-colors"
              >
                Удалить
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
