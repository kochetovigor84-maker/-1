import { useState, useEffect, useCallback } from 'react';
import { Car, CarFormData, CarStatus } from '../types/car';
import { initialCars } from '../data/mockData';

const STORAGE_KEY = 'fleet_cars_v2';

function loadCars(): Car[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (e) {
    console.error('Error loading cars from localStorage', e);
  }
  return initialCars;
}

function saveCars(cars: Car[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cars));
}

export function useCars() {
  const [cars, setCars] = useState<Car[]>(loadCars);

  useEffect(() => {
    saveCars(cars);
  }, [cars]);

  /**
   * Создание нового автомобиля
   */
  const addCar = useCallback((data: CarFormData) => {
    const now = new Date().toISOString();
    const newCar: Car = {
      ...data,
      id: crypto.randomUUID(),
      createdAt: now,
      updatedAt: now,
      archivedAt: null,
      archiveReason: null,
    };
    setCars(prev => [newCar, ...prev]);
    return newCar;
  }, []);

  /**
   * Обновление автомобиля
   */
  const updateCar = useCallback((id: string, data: CarFormData) => {
    setCars(prev =>
      prev.map(car =>
        car.id === id
          ? { ...car, ...data, updatedAt: new Date().toISOString() }
          : car
      )
    );
  }, []);

  /**
   * Удаление автомобиля (полное удаление, не рекомендуется)
   */
  const deleteCar = useCallback((id: string) => {
    setCars(prev => prev.filter(car => car.id !== id));
  }, []);

  /**
   * Архивация автомобиля (Soft Delete)
   * При продаже/списании:
   * - Статус меняется на Sold/Scrapped
   * - Очищаются department и responsiblePerson
   * - Заполняется archivedAt и archiveReason
   */
  const archiveCar = useCallback((id: string, status: 'Sold' | 'Scrapped', reason: string) => {
    setCars(prev =>
      prev.map(car =>
        car.id === id
          ? {
              ...car,
              status,
              department: '',
              responsiblePerson: '',
              archivedAt: new Date().toISOString(),
              archiveReason: reason,
              updatedAt: new Date().toISOString(),
            }
          : car
      )
    );
  }, []);

  /**
   * Восстановление из архива
   */
  const restoreCar = useCallback((id: string, department: string, responsiblePerson: string) => {
    setCars(prev =>
      prev.map(car =>
        car.id === id
          ? {
              ...car,
              status: 'Active' as CarStatus,
              department,
              responsiblePerson,
              archivedAt: null,
              archiveReason: null,
              updatedAt: new Date().toISOString(),
            }
          : car
      )
    );
  }, []);

  /**
   * Проверка уникальности VIN (кроме текущего авто при редактировании)
   */
  const isVinUnique = useCallback((vin: string, excludeId?: string): boolean => {
    return !cars.some(car => car.vin === vin && car.id !== excludeId);
  }, [cars]);

  return { cars, addCar, updateCar, deleteCar, archiveCar, restoreCar, isVinUnique };
}
