export type Transmission = 'Manual' | 'Auto' | 'Robot' | 'CVT';
export type DriveType = 'FWD' | 'RWD' | 'AWD' | '4WD';
export type Condition = 'Excellent' | 'Good' | 'NeedsAttention' | 'Broken';
export type InsuranceType = 'OSAGO' | 'KASKO' | 'DSAKO' | 'None';
export type CarStatus = 'Active' | 'InRepair' | 'Sold' | 'Scrapped' | 'Reserved';

// Типы алертов
export type InsuranceAlertLevel = 'none' | 'warning' | 'critical';
export type MaintenanceAlertLevel = 'none' | 'warning' | 'critical';

export interface Car {
  id: string;
  createdAt: string;
  updatedAt: string;
  // 1. Организационный учет
  department: string;
  responsiblePerson: string;
  // 2. Идентификация и характеристики
  brand: string;
  model: string;
  licensePlate: string;
  color: string;
  year: number;
  vin: string;
  transmission: Transmission;
  driveType: DriveType;
  // 3. Эксплуатация и состояние
  mileage: number;
  condition: Condition;
  lastMaintenanceDate: string | null;
  lastMaintenanceMileage: number | null; // Пробег на момент последнего ТО
  // 4. Юридическая информация и статус
  insuranceType: InsuranceType;
  insuranceExpiry: string | null;
  status: CarStatus;
  comments: string | null;
  // Архивные данные (заполняются при продаже/списании)
  archivedAt: string | null;
  archiveReason: string | null;
}

// Карточка авто с вычисленными алертами
export interface CarWithAlerts extends Car {
  insuranceAlert: InsuranceAlertLevel;
  maintenanceAlert: MaintenanceAlertLevel;
  daysUntilInsuranceExpiry: number | null;
  monthsSinceLastMaintenance: number | null;
  kmSinceLastMaintenance: number | null;
}

export interface CarFormData {
  department: string;
  responsiblePerson: string;
  brand: string;
  model: string;
  licensePlate: string;
  color: string;
  year: number;
  vin: string;
  transmission: Transmission;
  driveType: DriveType;
  mileage: number;
  condition: Condition;
  lastMaintenanceDate: string | null;
  lastMaintenanceMileage: number | null;
  insuranceType: InsuranceType;
  insuranceExpiry: string | null;
  status: CarStatus;
  comments: string | null;
}

// Фильтры для списка авто
export interface CarFilters {
  search: string;
  status: CarStatus | '';
  condition: Condition | '';
  department: string;
  hasInsuranceAlert: boolean;
  hasMaintenanceAlert: boolean;
  showArchived: boolean;
}

// Сортировка
export type SortField = 'brand' | 'model' | 'licensePlate' | 'year' | 'mileage' | 'status' | 'insuranceExpiry' | 'updatedAt';
export type SortDirection = 'asc' | 'desc';

export interface SortConfig {
  field: SortField;
  direction: SortDirection;
}
