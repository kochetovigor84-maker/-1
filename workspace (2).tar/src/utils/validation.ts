import { z } from 'zod';

export const carFormSchema = z.object({
  department: z.string().min(1, 'Укажите департамент'),
  responsiblePerson: z.string().min(1, 'Укажите ответственного'),
  brand: z.string().min(1, 'Укажите марку'),
  model: z.string().min(1, 'Укажите модель'),
  licensePlate: z.string().min(1, 'Укажите гос. номер'),
  color: z.string().min(1, 'Укажите цвет'),
  year: z.number().min(1990, 'Год не ранее 1990').max(2030, 'Год не позднее 2030'),
  vin: z.string().length(17, 'VIN должен содержать 17 символов'),
  transmission: z.enum(['Manual', 'Auto', 'Robot', 'CVT']),
  driveType: z.enum(['FWD', 'RWD', 'AWD', '4WD']),
  mileage: z.number().min(0, 'Пробег не может быть отрицательным'),
  condition: z.enum(['Excellent', 'Good', 'NeedsAttention', 'Broken']),
  lastMaintenanceDate: z.string().nullable(),
  insuranceType: z.enum(['OSAGO', 'KASKO', 'DSAKO', 'None']),
  insuranceExpiry: z.string().nullable(),
  status: z.enum(['Active', 'InRepair', 'Sold', 'Scrapped', 'Reserved']),
  comments: z.string().nullable(),
});

export type CarFormSchemaType = z.infer<typeof carFormSchema>;
