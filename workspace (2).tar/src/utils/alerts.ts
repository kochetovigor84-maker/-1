import { Car, CarWithAlerts, InsuranceAlertLevel, MaintenanceAlertLevel } from '../types/car';

const MS_PER_DAY = 24 * 60 * 60 * 1000;
const MS_PER_MONTH = 30.44 * MS_PER_DAY; // Среднее количество дней в месяце

/**
 * Вычисляет уровень алерта по страховке:
 * - 'critical': страховка истекла или истекает в течение 30 дней
 * - 'warning': страховка истекает в течение 60 дней
 * - 'none': всё ок
 */
export function calculateInsuranceAlert(insuranceExpiry: string | null): {
  level: InsuranceAlertLevel;
  daysUntilExpiry: number | null;
} {
  if (!insuranceExpiry) {
    return { level: 'none', daysUntilExpiry: null };
  }

  const expiryDate = new Date(insuranceExpiry);
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  expiryDate.setHours(0, 0, 0, 0);

  const diffMs = expiryDate.getTime() - now.getTime();
  const daysUntilExpiry = Math.ceil(diffMs / MS_PER_DAY);

  if (daysUntilExpiry <= 30) {
    return { level: 'critical', daysUntilExpiry };
  }

  return { level: 'none', daysUntilExpiry };
}

/**
 * Вычисляет уровень алерта по ТО:
 * - 'critical': ТО было > 12 месяцев назад ИЛИ пробег > 15000 км после ТО
 * - 'warning': ТО было > 6 месяцев назад ИЛИ пробег > 10000 км после ТО
 * - 'none': всё ок
 */
export function calculateMaintenanceAlert(
  lastMaintenanceDate: string | null,
  lastMaintenanceMileage: number | null,
  currentMileage: number
): {
  level: MaintenanceAlertLevel;
  monthsSinceLastMaintenance: number | null;
  kmSinceLastMaintenance: number | null;
} {
  let monthsSince: number | null = null;
  let kmSince: number | null = null;

  // Проверка по дате
  if (lastMaintenanceDate) {
    const mDate = new Date(lastMaintenanceDate);
    const now = new Date();
    const diffMs = now.getTime() - mDate.getTime();
    monthsSince = Math.floor(diffMs / MS_PER_MONTH);
  } else {
    // Если дата ТО не указана — считаем что требуется внимание
    monthsSince = null;
  }

  // Проверка по пробегу
  if (lastMaintenanceMileage !== null) {
    kmSince = currentMileage - lastMaintenanceMileage;
  }

  // Определяем уровень
  const criticalByDate = monthsSince !== null && monthsSince >= 12;
  const criticalByKm = kmSince !== null && kmSince >= 15000;
  const warningByDate = monthsSince !== null && monthsSince >= 6;
  const warningByKm = kmSince !== null && kmSince >= 10000;

  if (criticalByDate || criticalByKm) {
    return { level: 'critical', monthsSinceLastMaintenance: monthsSince, kmSinceLastMaintenance: kmSince };
  }

  if (warningByDate || warningByKm) {
    return { level: 'warning', monthsSinceLastMaintenance: monthsSince, kmSinceLastMaintenance: kmSince };
  }

  // Если дата ТО вообще не указана и авто активен
  if (!lastMaintenanceDate) {
    return { level: 'warning', monthsSinceLastMaintenance: null, kmSinceLastMaintenance: kmSince };
  }

  return { level: 'none', monthsSinceLastMaintenance: monthsSince, kmSinceLastMaintenance: kmSince };
}

/**
 * Обогащает объект Car вычисленными алертами
 */
export function enrichCarWithAlerts(car: Car): CarWithAlerts {
  const insurance = calculateInsuranceAlert(car.insuranceExpiry);
  const maintenance = calculateMaintenanceAlert(
    car.lastMaintenanceDate,
    car.lastMaintenanceMileage,
    car.mileage
  );

  return {
    ...car,
    insuranceAlert: insurance.level,
    maintenanceAlert: maintenance.level,
    daysUntilInsuranceExpiry: insurance.daysUntilExpiry,
    monthsSinceLastMaintenance: maintenance.monthsSinceLastMaintenance,
    kmSinceLastMaintenance: maintenance.kmSinceLastMaintenance,
  };
}

/**
 * Проверяет, является ли автомобиль архивным (продан/списан)
 */
export function isArchived(car: Car): boolean {
  return car.status === 'Sold' || car.status === 'Scrapped';
}

/**
 * Определяет CSS-класс для строки таблицы на основе алертов и статуса
 */
export function getRowBgClass(car: CarWithAlerts): string {
  if (car.status === 'Sold' || car.status === 'Scrapped') {
    return 'bg-gray-50 opacity-60';
  }
  if (car.insuranceAlert === 'critical') {
    return 'bg-red-50';
  }
  if (car.status === 'InRepair') {
    return 'bg-yellow-50';
  }
  if (car.maintenanceAlert === 'critical') {
    return 'bg-orange-50';
  }
  if (car.maintenanceAlert === 'warning') {
    return 'bg-amber-50/50';
  }
  return 'bg-white';
}

/**
 * Возвращает список ближайших событий (страховки и ТО)
 */
export function getUpcomingEvents(cars: Car[]): Array<{
  type: 'insurance' | 'maintenance';
  car: Car;
  date: string;
  description: string;
  urgency: 'critical' | 'warning' | 'info';
}> {
  const events: Array<{
    type: 'insurance' | 'maintenance';
    car: Car;
    date: string;
    description: string;
    urgency: 'critical' | 'warning' | 'info';
  }> = [];

  const now = new Date();

  cars.forEach(car => {
    if (isArchived(car)) return;

    // События по страховке
    if (car.insuranceExpiry) {
      const expiryDate = new Date(car.insuranceExpiry);
      const daysUntil = Math.ceil((expiryDate.getTime() - now.getTime()) / MS_PER_DAY);
      
      if (daysUntil <= 90) {
        events.push({
          type: 'insurance',
          car,
          date: car.insuranceExpiry,
          description: daysUntil <= 0
            ? `Страховка ${car.brand} ${car.model} (${car.licensePlate}) — ПРОСРОЧЕНА`
            : `Страховка ${car.brand} ${car.model} истекает через ${daysUntil} дн.`,
          urgency: daysUntil <= 30 ? 'critical' : 'warning',
        });
      }
    }

    // События по ТО
    if (car.lastMaintenanceDate) {
      const mDate = new Date(car.lastMaintenanceDate);
      const monthsSince = (now.getTime() - mDate.getTime()) / MS_PER_MONTH;
      
      if (monthsSince >= 5) {
        events.push({
          type: 'maintenance',
          car,
          date: car.lastMaintenanceDate,
          description: monthsSince >= 6
            ? `ТО ${car.brand} ${car.model} (${car.licensePlate}) — просрочено (${Math.floor(monthsSince)} мес.)`
            : `ТО ${car.brand} ${car.model} — скоро потребуется (${Math.floor(monthsSince)} мес. назад)`,
          urgency: monthsSince >= 6 ? 'critical' : 'warning',
        });
      }
    }
  });

  // Сортируем по срочности и дате
  const urgencyOrder = { critical: 0, warning: 1, info: 2 };
  events.sort((a, b) => {
    if (urgencyOrder[a.urgency] !== urgencyOrder[b.urgency]) {
      return urgencyOrder[a.urgency] - urgencyOrder[b.urgency];
    }
    return new Date(a.date).getTime() - new Date(b.date).getTime();
  });

  return events;
}
