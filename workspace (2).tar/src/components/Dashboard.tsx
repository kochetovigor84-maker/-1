import { Car } from '../types/car';
import {
  AlertTriangle,
  CheckCircle,
  Wrench,
  XCircle,
  Clock,
  Car as CarIcon,
} from 'lucide-react';

interface DashboardProps {
  cars: Car[];
}

export function Dashboard({ cars }: DashboardProps) {
  const totalCars = cars.length;
  const activeCars = cars.filter(c => c.status === 'Active').length;
  const inRepair = cars.filter(c => c.status === 'InRepair').length;
  const needsAttention = cars.filter(c => c.condition === 'NeedsAttention').length;
  const broken = cars.filter(c => c.condition === 'Broken').length;

  // Insurance expiring within 30 days
  const now = new Date();
  const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
  const insuranceExpiring = cars.filter(c => {
    if (!c.insuranceExpiry) return false;
    const expDate = new Date(c.insuranceExpiry);
    return expDate <= thirtyDaysFromNow && expDate >= now;
  });

  const insuranceExpired = cars.filter(c => {
    if (!c.insuranceExpiry) return false;
    const expDate = new Date(c.insuranceExpiry);
    return expDate < now;
  });

  // Maintenance overdue (more than 6 months)
  const sixMonthsAgo = new Date(now.getTime() - 180 * 24 * 60 * 60 * 1000);
  const maintenanceOverdue = cars.filter(c => {
    if (!c.lastMaintenanceDate) return true;
    const mDate = new Date(c.lastMaintenanceDate);
    return mDate < sixMonthsAgo && c.status === 'Active';
  });

  const totalMileage = cars.reduce((sum, c) => sum + c.mileage, 0);

  const stats = [
    {
      label: 'Всего автомобилей',
      value: totalCars,
      icon: CarIcon,
      color: 'bg-blue-500',
    },
    {
      label: 'Активные',
      value: activeCars,
      icon: CheckCircle,
      color: 'bg-green-500',
    },
    {
      label: 'В ремонте',
      value: inRepair,
      icon: Wrench,
      color: 'bg-orange-500',
    },
    {
      label: 'Требуют внимания',
      value: needsAttention,
      icon: AlertTriangle,
      color: 'bg-yellow-500',
    },
  ];

  const alerts = [
    ...insuranceExpired.map(c => ({
      type: 'error' as const,
      message: `Страховка ${c.brand} ${c.model} (${c.licensePlate}) — ПРОСРОЧЕНА`,
      carId: c.id,
    })),
    ...insuranceExpiring.map(c => ({
      type: 'warning' as const,
      message: `Страховка ${c.brand} ${c.model} (${c.licensePlate}) истекает ${new Date(c.insuranceExpiry!).toLocaleDateString('ru-RU')}`,
      carId: c.id,
    })),
    ...maintenanceOverdue.map(c => ({
      type: 'warning' as const,
      message: `ТО ${c.brand} ${c.model} (${c.licensePlate}) — просрочено более 6 месяцев`,
      carId: c.id,
    })),
    ...cars.filter(c => c.condition === 'Broken' && c.status === 'Active').map(c => ({
      type: 'error' as const,
      message: `${c.brand} ${c.model} (${c.licensePlate}) — неисправен`,
      carId: c.id,
    })),
  ];

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map(stat => (
          <div key={stat.label} className="bg-white rounded-xl shadow-sm border border-gray-100 p-5 flex items-center gap-4">
            <div className={`${stat.color} p-3 rounded-lg`}>
              <stat.icon className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              <p className="text-sm text-gray-500">{stat.label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Summary Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
          <p className="text-sm text-gray-500 mb-1">Общий пробег</p>
          <p className="text-xl font-bold text-gray-900">{totalMileage.toLocaleString('ru-RU')} км</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
          <p className="text-sm text-gray-500 mb-1">Средний пробег</p>
          <p className="text-xl font-bold text-gray-900">
            {totalCars > 0 ? Math.round(totalMileage / totalCars).toLocaleString('ru-RU') : 0} км
          </p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
          <p className="text-sm text-gray-500 mb-1">Департаментов</p>
          <p className="text-xl font-bold text-gray-900">
            {new Set(cars.map(c => c.department)).size}
          </p>
        </div>
      </div>

      {/* Alerts */}
      {alerts.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <Clock className="w-5 h-5 text-orange-500" />
            Уведомления ({alerts.length})
          </h3>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {alerts.map((alert, idx) => (
              <div
                key={idx}
                className={`p-3 rounded-lg border ${
                  alert.type === 'error'
                    ? 'bg-red-50 border-red-200 text-red-800'
                    : 'bg-yellow-50 border-yellow-200 text-yellow-800'
                }`}
              >
                <div className="flex items-center gap-2">
                  {alert.type === 'error' ? (
                    <XCircle className="w-4 h-4 flex-shrink-0" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                  )}
                  <span className="text-sm">{alert.message}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
