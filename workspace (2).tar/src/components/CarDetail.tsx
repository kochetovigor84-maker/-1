import { Car, CarStatus, Condition } from '../types/car';
import {
  X,
  MapPin,
  User,
  Gauge,
  Calendar,
  Shield,
  Car as CarIcon,
  Hash,
  Palette,
  Cog,
  ArrowRightLeft,
  Wrench,
  FileText,
} from 'lucide-react';
import { format } from 'date-fns';

interface CarDetailProps {
  car: Car;
  onClose: () => void;
  onEdit: (car: Car) => void;
}

const statusLabels: Record<CarStatus, string> = {
  Active: 'Активен',
  InRepair: 'В ремонте',
  Sold: 'Продан',
  Scrapped: 'Списан',
  Reserved: 'Зарезервирован',
};

const conditionLabels: Record<Condition, string> = {
  Excellent: 'Отличное',
  Good: 'Хорошее',
  NeedsAttention: 'Требует внимания',
  Broken: 'Неисправен',
};

const statusColors: Record<CarStatus, string> = {
  Active: 'bg-green-100 text-green-800',
  InRepair: 'bg-orange-100 text-orange-800',
  Sold: 'bg-blue-100 text-blue-800',
  Scrapped: 'bg-gray-100 text-gray-800',
  Reserved: 'bg-purple-100 text-purple-800',
};

const conditionColors: Record<Condition, string> = {
  Excellent: 'bg-emerald-100 text-emerald-800',
  Good: 'bg-blue-100 text-blue-800',
  NeedsAttention: 'bg-yellow-100 text-yellow-800',
  Broken: 'bg-red-100 text-red-800',
};

const transmissionLabels: Record<string, string> = {
  Manual: 'Механическая',
  Auto: 'Автоматическая',
  Robot: 'Роботизированная',
  CVT: 'Вариатор',
};

const driveLabels: Record<string, string> = {
  FWD: 'Передний',
  RWD: 'Задний',
  AWD: 'Полный (AWD)',
  '4WD': 'Полный (4WD)',
};

const insuranceLabels: Record<string, string> = {
  OSAGO: 'ОСАГО',
  KASKO: 'КАСКО',
  DSAKO: 'ДСАГО',
  None: 'Нет',
};

export function CarDetail({ car, onClose, onEdit }: CarDetailProps) {
  return (
    <div className="fixed inset-0 bg-black/50 flex items-start justify-center z-50 overflow-y-auto p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl my-8">
        {/* Header */}
        <div className="p-6 border-b border-gray-100">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">
                {car.brand} {car.model}
              </h2>
              <p className="text-gray-500 font-mono mt-1">{car.licensePlate}</p>
              <div className="flex gap-2 mt-3">
                <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${statusColors[car.status]}`}>
                  {statusLabels[car.status]}
                </span>
                <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${conditionColors[car.condition]}`}>
                  {conditionLabels[car.condition]}
                </span>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6">
          {/* Organization */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <MapPin className="w-5 h-5 text-blue-500" />
              <div>
                <p className="text-xs text-gray-500">Департамент</p>
                <p className="text-sm font-medium text-gray-900">{car.department}</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
              <User className="w-5 h-5 text-blue-500" />
              <div>
                <p className="text-xs text-gray-500">Ответственный</p>
                <p className="text-sm font-medium text-gray-900">{car.responsiblePerson}</p>
              </div>
            </div>
          </div>

          {/* Characteristics */}
          <div>
            <h3 className="text-sm font-semibold text-gray-700 uppercase tracking-wide mb-3">Характеристики</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="flex items-center gap-2">
                <CarIcon className="w-4 h-4 text-gray-400" />
                <div>
                  <p className="text-xs text-gray-500">Год</p>
                  <p className="text-sm font-medium">{car.year}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Palette className="w-4 h-4 text-gray-400" />
                <div>
                  <p className="text-xs text-gray-500">Цвет</p>
                  <p className="text-sm font-medium">{car.color}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Hash className="w-4 h-4 text-gray-400" />
                <div>
                  <p className="text-xs text-gray-500">VIN</p>
                  <p className="text-sm font-medium font-mono">{car.vin}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Cog className="w-4 h-4 text-gray-400" />
                <div>
                  <p className="text-xs text-gray-500">КПП</p>
                  <p className="text-sm font-medium">{transmissionLabels[car.transmission]}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <ArrowRightLeft className="w-4 h-4 text-gray-400" />
                <div>
                  <p className="text-xs text-gray-500">Привод</p>
                  <p className="text-sm font-medium">{driveLabels[car.driveType]}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Gauge className="w-4 h-4 text-gray-400" />
                <div>
                  <p className="text-xs text-gray-500">Пробег</p>
                  <p className="text-sm font-medium">{car.mileage.toLocaleString('ru-RU')} км</p>
                </div>
              </div>
            </div>
          </div>

          {/* Legal & Status */}
          <div>
            <h3 className="text-sm font-semibold text-gray-700 uppercase tracking-wide mb-3">Юридическая информация</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <Shield className="w-5 h-5 text-green-500" />
                <div>
                  <p className="text-xs text-gray-500">Страховка</p>
                  <p className="text-sm font-medium">
                    {insuranceLabels[car.insuranceType]}
                    {car.insuranceExpiry && (
                      <span className="text-gray-500"> до {format(new Date(car.insuranceExpiry), 'dd.MM.yyyy')}</span>
                    )}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <Wrench className="w-5 h-5 text-orange-500" />
                <div>
                  <p className="text-xs text-gray-500">Последнее ТО</p>
                  <p className="text-sm font-medium">
                    {car.lastMaintenanceDate
                      ? format(new Date(car.lastMaintenanceDate), 'dd.MM.yyyy')
                      : 'Не указано'}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Dates */}
          <div className="text-xs text-gray-400 space-y-1">
            <p>Создано: {format(new Date(car.createdAt), 'dd.MM.yyyy HH:mm')}</p>
            <p>Обновлено: {format(new Date(car.updatedAt), 'dd.MM.yyyy HH:mm')}</p>
          </div>

          {/* Comments */}
          {car.comments && (
            <div className="p-4 bg-yellow-50 border border-yellow-100 rounded-lg">
              <div className="flex items-center gap-2 mb-1">
                <FileText className="w-4 h-4 text-yellow-600" />
                <p className="text-xs font-medium text-yellow-700">Комментарии</p>
              </div>
              <p className="text-sm text-yellow-800">{car.comments}</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-gray-100 flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
          >
            Закрыть
          </button>
          <button
            onClick={() => onEdit(car)}
            className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
          >
            Редактировать
          </button>
        </div>
      </div>
    </div>
  );
}
