import { Car, CarStatus, Condition } from '../types/car';
import { CarCard } from './CarCard';
import { Search, Filter, Plus, LayoutGrid } from 'lucide-react';
import { useState } from 'react';

interface CarListProps {
  cars: Car[];
  onEdit: (car: Car) => void;
  onDelete: (id: string) => void;
  onView: (car: Car) => void;
  onAdd: () => void;
}

export function CarList({ cars, onEdit, onDelete, onView, onAdd }: CarListProps) {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<CarStatus | ''>('');
  const [conditionFilter, setConditionFilter] = useState<Condition | ''>('');
  const [departmentFilter, setDepartmentFilter] = useState('');

  const departments = [...new Set(cars.map(c => c.department))].sort();

  const filteredCars = cars.filter(car => {
    const searchStr = search.toLowerCase();
    const matchesSearch =
      !search ||
      car.brand.toLowerCase().includes(searchStr) ||
      car.model.toLowerCase().includes(searchStr) ||
      car.licensePlate.toLowerCase().includes(searchStr) ||
      car.vin.toLowerCase().includes(searchStr) ||
      car.responsiblePerson.toLowerCase().includes(searchStr) ||
      car.department.toLowerCase().includes(searchStr);

    const matchesStatus = !statusFilter || car.status === statusFilter;
    const matchesCondition = !conditionFilter || car.condition === conditionFilter;
    const matchesDepartment = !departmentFilter || car.department === departmentFilter;

    return matchesSearch && matchesStatus && matchesCondition && matchesDepartment;
  });

  const hasFilters = search || statusFilter || conditionFilter || departmentFilter;

  return (
    <div className="space-y-4">
      {/* Search and Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
        <div className="flex flex-col lg:flex-row gap-3">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Поиск по марке, модели, номеру, VIN, ответственному..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-2">
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value as CarStatus | '')}
              className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Все статусы</option>
              <option value="Active">Активные</option>
              <option value="InRepair">В ремонте</option>
              <option value="Sold">Проданные</option>
              <option value="Scrapped">Списанные</option>
              <option value="Reserved">Зарезервированные</option>
            </select>

            <select
              value={conditionFilter}
              onChange={e => setConditionFilter(e.target.value as Condition | '')}
              className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Все состояния</option>
              <option value="Excellent">Отличное</option>
              <option value="Good">Хорошее</option>
              <option value="NeedsAttention">Требует внимания</option>
              <option value="Broken">Неисправен</option>
            </select>

            <select
              value={departmentFilter}
              onChange={e => setDepartmentFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Все департаменты</option>
              {departments.map(d => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>

            {hasFilters && (
              <button
                onClick={() => {
                  setSearch('');
                  setStatusFilter('');
                  setConditionFilter('');
                  setDepartmentFilter('');
                }}
                className="px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              >
                Сбросить
              </button>
            )}
          </div>

          {/* Add button */}
          <button
            onClick={onAdd}
            className="px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2 whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            Добавить
          </button>
        </div>

        {/* Results count */}
        <div className="mt-3 flex items-center justify-between">
          <p className="text-sm text-gray-500">
            Найдено: {filteredCars.length} из {cars.length}
          </p>
          <Filter className="w-4 h-4 text-gray-400" />
        </div>
      </div>

      {/* Car Grid */}
      {filteredCars.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredCars.map(car => (
            <CarCard
              key={car.id}
              car={car}
              onEdit={onEdit}
              onDelete={onDelete}
              onView={onView}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-12 bg-white rounded-xl border border-gray-100">
          <LayoutGrid className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">
            {hasFilters ? 'Нет автомобилей, соответствующих фильтрам' : 'Нет автомобилей в системе'}
          </p>
          {!hasFilters && (
            <button
              onClick={onAdd}
              className="mt-3 px-4 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition-colors"
            >
              Добавить первый автомобиль
            </button>
          )}
        </div>
      )}
    </div>
  );
}
