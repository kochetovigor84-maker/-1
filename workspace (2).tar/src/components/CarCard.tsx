import { Car, CarStatus, Condition } from '../types/car';
import {
  MapPin,
  User,
  Gauge,
  Calendar,
  Shield,
  Edit,
  Trash2,
  Eye,
} from 'lucide-react';
import { format } from 'date-fns';

interface CarCardProps {
  car: Car;
  onEdit: (car: Car) => void;
  onDelete: (id: string) => void;
  onView: (car: Car) => void;
}

const statusColors: Record<CarStatus, string> = {
  Active: 'bg-green-100 text-green-800',
  InRepair: 'bg-orange-100 text-orange-800',
  Sold: 'bg-blue-100 text-blue-800',
  Scrapped: 'bg-gray-100 text-gray-800',
  Reserved: 'bg-purple-100 text-purple-800',
};

const statusLabels: Record<CarStatus, string> = {
  Active: 'Активен',
  InRepair: 'В ремонте',
  Sold: 'Продан',
  Scrapped: 'Списан',
  Reserved: 'Зарезервирован',
};

const conditionColors: Record<Condition, string> = {
  Excellent: 'bg-emerald-100 text-emerald-800',
  Good: 'bg-blue-100 text-blue-800',
  NeedsAttention: 'bg-yellow-100 text-yellow-800',
  Broken: 'bg-red-100 text-red-800',
};

const conditionLabels: Record<Condition, string> = {
  Excellent: 'Отличное',
  Good: 'Хорошее',
  NeedsAttention: 'Требует внимания',
  Broken: 'Неисправен',
};

function isInsuranceExpiringSoon(car: Car): boolean {
  if (!car.insuranceExpiry) return false;
  const expDate = new Date(car.insuranceExpiry);
  const now = new Date();
  const thirtyDays = 30 * 24 * 60 * 60 * 1000;
  return expDate.getTime() - now.getTime() < thirtyDays;
}

function isInsuranceExpired(car: Car): boolean {
  if (!car.insuranceExpiry) return false;
  return new Date(car.insuranceExpiry) < new Date();
}

export function CarCard({ car, onEdit, onDelete, onView }: CarCardProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow overflow-hidden">
      {/* Header with status */}
      <div className="p-4 border-b border-gray-50">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="font-bold text-lg text-gray-900">
              {car.brand} {car.model}
            </h3>
            <p className="text-sm text-gray-500 font-mono">{car.licensePlate}</p>
          </div>
          <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${statusColors[car.status]}`}>
            {statusLabels[car.status]}
          </span>
        </div>
      </div>

      {/* Body */}
      <div className="p-4 space-y-3">
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div className="flex items-center gap-2 text-gray-600">
            <MapPin className="w-4 h-4 text-gray-400" />
            <span className="truncate">{car.department}</span>
          </div>
          <div className="flex items-center gap-2 text-gray-600">
            <User className="w-4 h-4 text-gray-400" />
            <span className="truncate">{car.responsiblePerson}</span>
          </div>
          <div className="flex items-center gap-2 text-gray-600">
            <Gauge className="w-4 h-4 text-gray-400" />
            <span>{car.mileage.toLocaleString('ru-RU')} км</span>
          </div>
          <div className="flex items-center gap-2 text-gray-600">
            <Calendar className="w-4 h-4 text-gray-400" />
            <span>{car.year} г.</span>
          </div>
        </div>

        {/* Condition & Insurance */}
        <div className="flex flex-wrap gap-2">
          <span className={`px-2 py-0.5 rounded text-xs font-medium ${conditionColors[car.condition]}`}>
            {conditionLabels[car.condition]}
          </span>
          {car.insuranceType !== 'None' && (
            <span
              className={`px-2 py-0.5 rounded text-xs font-medium flex items-center gap-1 ${
                isInsuranceExpired(car)
                  ? 'bg-red-100 text-red-800'
                  : isInsuranceExpiringSoon(car)
                  ? 'bg-yellow-100 text-yellow-800'
                  : 'bg-gray-100 text-gray-700'
              }`}
            >
              <Shield className="w-3 h-3" />
              {car.insuranceType}
              {car.insuranceExpiry && (
                <span> до {format(new Date(car.insuranceExpiry), 'dd.MM.yyyy')}</span>
              )}
            </span>
          )}
          <span className="px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-700">
            {car.transmission === 'Auto' ? 'АКПП' : car.transmission === 'Manual' ? 'МКПП' : car.transmission === 'Robot' ? 'РКПП' : 'Вариатор'}
          </span>
          <span className="px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-700">
            {car.driveType}
          </span>
        </div>

        {car.comments && (
          <p className="text-xs text-gray-500 italic line-clamp-2">{car.comments}</p>
        )}
      </div>

      {/* Actions */}
      <div className="px-4 py-3 bg-gray-50 border-t border-gray-100 flex items-center justify-end gap-2">
        <button
          onClick={() => onView(car)}
          className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
          title="Просмотр"
        >
          <Eye className="w-4 h-4" />
        </button>
        <button
          onClick={() => onEdit(car)}
          className="p-2 text-gray-500 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors"
          title="Редактировать"
        >
          <Edit className="w-4 h-4" />
        </button>
        <button
          onClick={() => onDelete(car.id)}
          className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
          title="Удалить"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
