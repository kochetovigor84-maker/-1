import { useState } from 'react';
import { Car, CarFormData, Transmission, DriveType, Condition, InsuranceType, CarStatus } from '../types/car';
import { carFormSchema } from '../utils/validation';
import { X, Save } from 'lucide-react';

interface CarFormProps {
  car?: Car | null;
  onSubmit: (data: CarFormData) => void;
  onClose: () => void;
}

const emptyForm: CarFormData = {
  department: '',
  responsiblePerson: '',
  brand: '',
  model: '',
  licensePlate: '',
  color: '',
  year: new Date().getFullYear(),
  vin: '',
  transmission: 'Auto',
  driveType: 'FWD',
  mileage: 0,
  condition: 'Good',
  lastMaintenanceDate: null,
  insuranceType: 'OSAGO',
  insuranceExpiry: null,
  status: 'Active',
  comments: null,
};

export function CarForm({ car, onSubmit, onClose }: CarFormProps) {
  const [form, setForm] = useState<CarFormData>(() => {
    if (car) {
      return {
        department: car.department,
        responsiblePerson: car.responsiblePerson,
        brand: car.brand,
        model: car.model,
        licensePlate: car.licensePlate,
        color: car.color,
        year: car.year,
        vin: car.vin,
        transmission: car.transmission,
        driveType: car.driveType,
        mileage: car.mileage,
        condition: car.condition,
        lastMaintenanceDate: car.lastMaintenanceDate,
        insuranceType: car.insuranceType,
        insuranceExpiry: car.insuranceExpiry,
        status: car.status,
        comments: car.comments,
      };
    }
    return emptyForm;
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleChange = (field: keyof CarFormData, value: string | number | null) => {
    setForm(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => {
        const next = { ...prev };
        delete next[field];
        return next;
      });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const result = carFormSchema.safeParse({
      ...form,
      year: Number(form.year),
      mileage: Number(form.mileage),
    });

    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.issues.forEach(issue => {
        const field = issue.path[0] as string;
        fieldErrors[field] = issue.message;
      });
      setErrors(fieldErrors);
      return;
    }

    onSubmit(result.data);
  };

  const inputClass = (field: string) =>
    `w-full px-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${
      errors[field] ? 'border-red-300 bg-red-50' : 'border-gray-300'
    }`;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-start justify-center z-50 overflow-y-auto p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-3xl my-8">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <h2 className="text-xl font-bold text-gray-900">
            {car ? 'Редактировать автомобиль' : 'Добавить автомобиль'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Section 1: Organization */}
          <fieldset className="space-y-4">
            <legend className="text-sm font-semibold text-gray-700 uppercase tracking-wide">
              1. Организационный учёт
            </legend>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Департамент *</label>
                <input
                  type="text"
                  value={form.department}
                  onChange={e => handleChange('department', e.target.value)}
                  className={inputClass('department')}
                  placeholder="Отдел продаж"
                />
                {errors.department && <p className="text-xs text-red-600 mt-1">{errors.department}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Ответственный *</label>
                <input
                  type="text"
                  value={form.responsiblePerson}
                  onChange={e => handleChange('responsiblePerson', e.target.value)}
                  className={inputClass('responsiblePerson')}
                  placeholder="Иванов И.И."
                />
                {errors.responsiblePerson && <p className="text-xs text-red-600 mt-1">{errors.responsiblePerson}</p>}
              </div>
            </div>
          </fieldset>

          {/* Section 2: Identification */}
          <fieldset className="space-y-4">
            <legend className="text-sm font-semibold text-gray-700 uppercase tracking-wide">
              2. Идентификация и характеристики
            </legend>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Марка *</label>
                <input
                  type="text"
                  value={form.brand}
                  onChange={e => handleChange('brand', e.target.value)}
                  className={inputClass('brand')}
                  placeholder="Toyota"
                />
                {errors.brand && <p className="text-xs text-red-600 mt-1">{errors.brand}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Модель *</label>
                <input
                  type="text"
                  value={form.model}
                  onChange={e => handleChange('model', e.target.value)}
                  className={inputClass('model')}
                  placeholder="Camry"
                />
                {errors.model && <p className="text-xs text-red-600 mt-1">{errors.model}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Гос. номер *</label>
                <input
                  type="text"
                  value={form.licensePlate}
                  onChange={e => handleChange('licensePlate', e.target.value)}
                  className={inputClass('licensePlate')}
                  placeholder="А123БВ 77"
                />
                {errors.licensePlate && <p className="text-xs text-red-600 mt-1">{errors.licensePlate}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Цвет *</label>
                <input
                  type="text"
                  value={form.color}
                  onChange={e => handleChange('color', e.target.value)}
                  className={inputClass('color')}
                  placeholder="Белый"
                />
                {errors.color && <p className="text-xs text-red-600 mt-1">{errors.color}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Год выпуска *</label>
                <input
                  type="number"
                  value={form.year}
                  onChange={e => handleChange('year', Number(e.target.value))}
                  className={inputClass('year')}
                  min={1990}
                  max={2030}
                />
                {errors.year && <p className="text-xs text-red-600 mt-1">{errors.year}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">VIN *</label>
                <input
                  type="text"
                  value={form.vin}
                  onChange={e => handleChange('vin', e.target.value.toUpperCase())}
                  className={inputClass('vin')}
                  placeholder="JTDKN3DU5A0123456"
                  maxLength={17}
                />
                {errors.vin && <p className="text-xs text-red-600 mt-1">{errors.vin}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">КПП *</label>
                <select
                  value={form.transmission}
                  onChange={e => handleChange('transmission', e.target.value)}
                  className={inputClass('transmission')}
                >
                  <option value="Manual">Механика</option>
                  <option value="Auto">Автомат</option>
                  <option value="Robot">Робот</option>
                  <option value="CVT">Вариатор</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Привод *</label>
                <select
                  value={form.driveType}
                  onChange={e => handleChange('driveType', e.target.value)}
                  className={inputClass('driveType')}
                >
                  <option value="FWD">Передний (FWD)</option>
                  <option value="RWD">Задний (RWD)</option>
                  <option value="AWD">Полный (AWD)</option>
                  <option value="4WD">Полный (4WD)</option>
                </select>
              </div>
            </div>
          </fieldset>

          {/* Section 3: Operation */}
          <fieldset className="space-y-4">
            <legend className="text-sm font-semibold text-gray-700 uppercase tracking-wide">
              3. Эксплуатация и состояние
            </legend>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Пробег (км) *</label>
                <input
                  type="number"
                  value={form.mileage}
                  onChange={e => handleChange('mileage', Number(e.target.value))}
                  className={inputClass('mileage')}
                  min={0}
                />
                {errors.mileage && <p className="text-xs text-red-600 mt-1">{errors.mileage}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Состояние *</label>
                <select
                  value={form.condition}
                  onChange={e => handleChange('condition', e.target.value)}
                  className={inputClass('condition')}
                >
                  <option value="Excellent">Отличное</option>
                  <option value="Good">Хорошее</option>
                  <option value="NeedsAttention">Требует внимания</option>
                  <option value="Broken">Неисправен</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Дата последнего ТО</label>
                <input
                  type="date"
                  value={form.lastMaintenanceDate || ''}
                  onChange={e => handleChange('lastMaintenanceDate', e.target.value || null)}
                  className={inputClass('lastMaintenanceDate')}
                />
              </div>
            </div>
          </fieldset>

          {/* Section 4: Legal */}
          <fieldset className="space-y-4">
            <legend className="text-sm font-semibold text-gray-700 uppercase tracking-wide">
              4. Юридическая информация и статус
            </legend>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Тип страховки *</label>
                <select
                  value={form.insuranceType}
                  onChange={e => handleChange('insuranceType', e.target.value)}
                  className={inputClass('insuranceType')}
                >
                  <option value="OSAGO">ОСАГО</option>
                  <option value="KASKO">КАСКО</option>
                  <option value="DSAKO">ДСАГО</option>
                  <option value="None">Нет</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Срок страховки</label>
                <input
                  type="date"
                  value={form.insuranceExpiry || ''}
                  onChange={e => handleChange('insuranceExpiry', e.target.value || null)}
                  className={inputClass('insuranceExpiry')}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Статус *</label>
                <select
                  value={form.status}
                  onChange={e => handleChange('status', e.target.value)}
                  className={inputClass('status')}
                >
                  <option value="Active">Активен</option>
                  <option value="InRepair">В ремонте</option>
                  <option value="Sold">Продан</option>
                  <option value="Scrapped">Списан</option>
                  <option value="Reserved">Зарезервирован</option>
                </select>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Комментарии</label>
              <textarea
                value={form.comments || ''}
                onChange={e => handleChange('comments', e.target.value || null)}
                className={inputClass('comments')}
                rows={3}
                placeholder="Дополнительная информация..."
              />
            </div>
          </fieldset>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              {car ? 'Сохранить' : 'Добавить'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
